#include "dsp.h"
#include "tables.h"
#include <string.h>
/* Explicit rounding avoids implementation-defined negative right shifts. */
static int32_t round_shift(int64_t x, unsigned bits)
{
    int64_t half = (int64_t)1 << (bits-1);
    return x >= 0 ? (int32_t)((x+half) >> bits)
                  : -(int32_t)((-x+half) >> bits);
}
uint32_t integer_sqrt64(uint64_t x)
{
    uint64_t result=0, bit=(uint64_t)1<<62;
    while(bit>x) bit>>=2;
    while(bit) {
        if(x>=result+bit) { x-=result+bit; result=(result>>1)+bit; }
        else result>>=1;
        bit>>=2;
    }
    return (uint32_t)result;
}
void lpf_reset(lpf_t *s, uint32_t alpha_q30)
{
    memset(s,0,sizeof(*s));
    s->alpha_q30=alpha_q30;
    /* exp(-10) settling bound for a one-pole filter. */
    if(alpha_q30) s->warm_samples=(uint32_t)(((uint64_t)10*LPF_ONE+alpha_q30-1)/alpha_q30);
}
static int32_t sample_q3(lpf_t *s, uint16_t x)
{
    if(!s->alpha_q30) return (int32_t)x*8;
    if(!s->initialized) { s->state_q16=(int32_t)x*65536; s->initialized=1; }
    else {
        int64_t difference=(int64_t)x*65536-s->state_q16;
        s->state_q16 += round_shift(difference*s->alpha_q30,30);
    }
    if(s->warm_samples) --s->warm_samples;
    return round_shift(s->state_q16,13);
}
void spectrum_compute(const uint16_t raw[FFT_N], lpf_t *s,
                      unsigned window, spectrum_t *out)
{
    int32_t re[FFT_N], im[FFT_N], mean=0, window_sum=0;
    unsigned n,j,k,length;
    const int16_t *w=windows[window<3?window:1];
    memset(out,0,sizeof(*out));
    out->minimum=4095;
    out->warming=(uint8_t)(s->warm_samples!=0);
    for(n=0;n<FFT_N;n++) {
        if(raw[n]<out->minimum) out->minimum=raw[n];
        if(raw[n]>out->maximum) out->maximum=raw[n];
        if(raw[n]<=4 || raw[n]>=4091) ++out->clipped;
        re[n]=sample_q3(s,raw[n]); mean+=re[n];
        window_sum+=w[n];
    }
    out->window_sum=(uint32_t)window_sum;
    mean=round_shift(mean,7);
    for(n=0;n<FFT_N;n++) {
        re[n]=round_shift((int64_t)(re[n]-mean)*w[n],15);
        im[n]=0;
    }
    for(n=1,j=0;n<FFT_N;n++) {
        unsigned bit=FFT_N>>1;
        for(;j&bit;bit>>=1) j^=bit;
        j^=bit;
        if(n<j) { int32_t t=re[n]; re[n]=re[j]; re[j]=t; }
    }
    for(length=2;length<=FFT_N;length<<=1) {
        unsigned half=length>>1, stride=FFT_N/length;
        for(n=0;n<FFT_N;n+=length) for(j=0;j<half;j++) {
            int32_t tr,ti,ar,ai;
            k=j*stride;
            tr=round_shift((int64_t)tw_re[k]*re[n+j+half]
                          -(int64_t)tw_im[k]*im[n+j+half],15);
            ti=round_shift((int64_t)tw_re[k]*im[n+j+half]
                          +(int64_t)tw_im[k]*re[n+j+half],15);
            ar=re[n+j]; ai=im[n+j];
            re[n+j]=ar+tr; im[n+j]=ai+ti;
            re[n+j+half]=ar-tr; im[n+j+half]=ai-ti;
        }
    }
    for(k=0;k<FFT_BINS;k++) {
        uint64_t power=(uint64_t)((int64_t)re[k]*re[k])
                      +(uint64_t)((int64_t)im[k]*im[k]);
        uint32_t mag=integer_sqrt64(power);
        /* A = 2*|X| / (8*sum(w/32768)); Q16 output.
           DC and Nyquist are not doubled. */
        uint64_t scale=(k==0 || k==FFT_N/2)?268435456ULL:536870912ULL;
        out->amplitude_q16[k]=(uint32_t)(((uint64_t)mag*scale+out->window_sum/2)/out->window_sum);
    }
    /* DC intentionally removed. Do not present a windowed residual as measured DC. */
    out->amplitude_q16[0]=0;
}
