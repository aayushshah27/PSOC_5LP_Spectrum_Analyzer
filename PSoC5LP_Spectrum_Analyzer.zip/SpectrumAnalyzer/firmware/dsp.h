#ifndef ANALYZER_DSP_H
#define ANALYZER_DSP_H
#include <stdint.h>
#define FFT_N 128
#define FFT_BINS 65
#define LPF_ONE 1073741824UL
/* Original implementation: Q15 windows/twiddles, Q3 ADC-count data,
   unscaled 32-bit butterflies, 64-bit products, integer magnitudes. */
typedef struct {
    uint32_t alpha_q30;
    int32_t state_q16;
    uint32_t warm_samples;
    uint8_t initialized;
} lpf_t;
typedef struct {
    uint32_t amplitude_q16[FFT_BINS]; /* single-sided ADC counts, Q16 */
    uint32_t window_sum;
    uint16_t minimum, maximum, clipped;
    uint8_t warming;
} spectrum_t;
void lpf_reset(lpf_t *s, uint32_t alpha_q30);
void spectrum_compute(const uint16_t raw[FFT_N], lpf_t *filter,
                      unsigned window, spectrum_t *out);
uint32_t integer_sqrt64(uint64_t x);
#endif
