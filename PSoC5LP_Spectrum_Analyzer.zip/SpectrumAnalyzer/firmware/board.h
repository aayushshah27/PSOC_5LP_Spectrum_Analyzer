#ifndef ANALYZER_BOARD_H
#define ANALYZER_BOARD_H
#include <stdint.h>
void board_init(void);
void board_capture_start(uint32_t requested_fs);
int board_read_block(uint16_t out[128], uint32_t *capture_sequence, uint32_t *skipped);
uint32_t board_cycles(void);
uint32_t board_milliseconds(void);
int board_rx_byte(void);
void board_transport_poll(void);
int board_send(const uint8_t *data,unsigned length);
extern volatile uint32_t board_fault, board_captured, board_copy_max;
extern uint32_t board_divisor;
#endif
