#ifndef ANALYZER_WIRE_H
#define ANALYZER_WIRE_H
#include <stdint.h>
#define WIRE_FIELDS 24
#define WIRE_SIZE (8+WIRE_FIELDS*4+65*4+4)
/* All integers little endian, no compiler structure layout on the wire. */
enum { M_EPOCH, M_FRAME, M_CAPTURE, M_CLOCK_HZ, M_DIVISOR,
       M_ELAPSED_MS, M_VALID, M_CAPTURED, M_SKIPPED, M_TX_DROPPED,
       M_FAULT, M_CLIPPED, M_DSP_CYCLES, M_MAX_DSP_CYCLES, M_MAX_COPY_CYCLES,
       M_WINDOW, M_ALPHA, M_WARM, M_COMMAND_ERRORS, M_RAW_MIN, M_RAW_MAX,
       M_CPU_HZ, M_FLAGS, M_WINDOW_SUM };
/* flags: bit 0 filter settling, bit 1 ADC clipping, bit 2 gap before frame. */
uint32_t wire_crc32(const uint8_t *data, unsigned length);
void wire_pack(uint8_t *dst, const uint32_t meta[WIRE_FIELDS],
               const uint32_t amplitudes[65]);
#endif
