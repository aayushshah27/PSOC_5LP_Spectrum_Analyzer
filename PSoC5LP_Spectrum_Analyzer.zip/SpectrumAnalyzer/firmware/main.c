#include "project.h"
#include "config.h"
#include "board.h"
#include "dsp.h"
#include "wire.h"
#include <stdlib.h>
#include <string.h>
static uint16_t raw[FFT_N];
static spectrum_t spectrum;
static lpf_t filter;
static uint32_t meta[WIRE_FIELDS], epoch, epoch_ms, valid, skipped_total;
static uint32_t tx_dropped, command_errors, last_dsp, max_dsp, frame;
static uint32_t window=1, requested_fs=INITIAL_FS;
static uint8_t packet[WIRE_SIZE];
static void restart(void)
{
    board_capture_start(requested_fs);
    ++epoch; epoch_ms=board_milliseconds();
    valid=skipped_total=tx_dropped=last_dsp=max_dsp=frame=0;
    memset(&spectrum,0,sizeof(spectrum));
    memset(meta,0,sizeof(meta));
    lpf_reset(&filter,filter.alpha_q30);
}
static void command(const char *s)
{
    char *end;
    unsigned long value;
    if(strcmp(s,"R")==0) {restart();return;}
    if(strlen(s)<3 || s[1]!=' ' || s[2]<'0' || s[2]>'9') {++command_errors;return;}
    value=strtoul(s+2,&end,10);
    if(*end) {++command_errors;return;}
    switch(s[0]) {
    case 'S':
        if(value<MIN_FS || value>MAX_FS) {++command_errors;return;}
        requested_fs=(uint32_t)value; lpf_reset(&filter,0); restart(); break;
    case 'W':
        if(value>2) {++command_errors;return;}
        window=(uint32_t)value; restart(); break;
    case 'F':
        /* 0=bypass, or >=1/4096 to bound settling work and fixed-point resolution. */
        if(value>LPF_ONE || (value && value<262144UL)) {++command_errors;return;}
        lpf_reset(&filter,(uint32_t)value); restart(); break;
    default: ++command_errors; break;
    }
}
int main(void)
{
    char line[40]; unsigned used=0; uint8_t overflow=0;
    uint32_t last_tx=0;
    board_init(); CyGlobalIntEnable;
    lpf_reset(&filter,0); restart();
    for(;;) {
        int c; unsigned budget=32;
        uint32_t now,sequence=0,skipped=0,start;
        board_transport_poll();
        while(budget-- && (c=board_rx_byte())>=0) {
            if(c=='\n') {
                if(overflow) ++command_errors;
                else {line[used]=0;command(line);}
                used=0;overflow=0;
            } else if(c!='\r') {
                if(used+1<sizeof(line)) line[used++]=(char)c;
                else overflow=1;
            }
        }
        if(board_read_block(raw,&sequence,&skipped)) {
            skipped_total+=skipped;
            if(skipped) lpf_reset(&filter,filter.alpha_q30);
            start=board_cycles();
            Probe_FFT_Write(1);
            spectrum_compute(raw,&filter,window,&spectrum);
            Probe_FFT_Write(0);
            last_dsp=board_cycles()-start;
            if(last_dsp>max_dsp) max_dsp=last_dsp;
            ++frame;
            if(!spectrum.warming && !spectrum.clipped && !board_fault) ++valid;
            meta[M_FLAGS]=(spectrum.warming?1UL:0UL)|(spectrum.clipped?2UL:0UL)|(skipped?4UL:0UL);
            meta[M_CAPTURE]=sequence;
        }
        now=board_milliseconds();
        if((uint32_t)(now-last_tx)>=TX_INTERVAL_MS) {
            last_tx=now;
            meta[M_EPOCH]=epoch;meta[M_FRAME]=frame;
            meta[M_CLOCK_HZ]=SAMPLE_SOURCE_HZ;meta[M_DIVISOR]=board_divisor;
            meta[M_ELAPSED_MS]=now-epoch_ms;meta[M_VALID]=valid;
            meta[M_CAPTURED]=board_captured;meta[M_SKIPPED]=skipped_total;
            meta[M_TX_DROPPED]=tx_dropped;meta[M_FAULT]=board_fault;
            meta[M_CLIPPED]=spectrum.clipped;meta[M_DSP_CYCLES]=last_dsp;
            meta[M_MAX_DSP_CYCLES]=max_dsp;meta[M_MAX_COPY_CYCLES]=board_copy_max;
            meta[M_WINDOW]=window;meta[M_ALPHA]=filter.alpha_q30;
            meta[M_WARM]=filter.warm_samples;meta[M_COMMAND_ERRORS]=command_errors;
            meta[M_RAW_MIN]=spectrum.minimum;meta[M_RAW_MAX]=spectrum.maximum;
            meta[M_CPU_HZ]=CPU_HZ;meta[M_WINDOW_SUM]=spectrum.window_sum;
            wire_pack(packet,meta,spectrum.amplitude_q16);
            if(!board_send(packet,sizeof(packet))) ++tx_dropped;
        }
    }
}
