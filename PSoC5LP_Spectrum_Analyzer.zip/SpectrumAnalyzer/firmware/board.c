#include "project.h"
#include "config.h"
#include "board.h"
#include "wire.h"
#include <string.h>
#define REG32(a) (*(volatile uint32_t *)(a))
#define DWT_CYCCNT REG32(0xe0001004UL)
/* 1-KiB alignment prevents this 1-KiB ring crossing a DMA high-address boundary. */
static volatile int16_t dma_ring[DMA_RING_BLOCKS][128] __attribute__((aligned(1024)));
static uint8 dma_channel, td[DMA_RING_BLOCKS];
static volatile uint32_t last_dma_tick;
static uint32_t expected_block_cycles, consumed, resource_fault;
static int32_t raw_correction;
static uint8_t tx[WIRE_SIZE];
static unsigned tx_length, tx_offset;
static uint32_t last_tick;
static uint64_t total_cycles;
volatile uint32_t board_fault, board_captured, board_copy_max;
uint32_t board_divisor;
/* Fault bits: 1 DMA cadence; 2 copy budget; 4 SRAM bank boundary;
   8 DMA API/allocation; 16 raw format/range; 32 ADC/DMA timeout. */
uint32_t board_cycles(void) { return DWT_CYCCNT; }
uint32_t board_milliseconds(void)
{
    uint32_t now=board_cycles();
    total_cycles+=(uint32_t)(now-last_tick); last_tick=now;
    return (uint32_t)(total_cycles/(CPU_HZ/1000UL));
}
CY_ISR(dma_complete)
{
    uint32_t now=board_cycles();
    if(board_captured) {
        uint32_t elapsed=now-last_dma_tick;
        if(elapsed>expected_block_cycles+expected_block_cycles/2 ||
           elapsed<expected_block_cycles/2) board_fault|=1;
    }
    last_dma_tick=now;
    ++board_captured;
}
static void capture_stop(void)
{
    SampClock_Stop();
    CyDelayUs(20); /* allow an in-flight conversion and DMA burst to finish */
    CyDmaChDisable(dma_channel);
    isr_dma_Disable(); isr_dma_ClearPending();
}
void board_capture_start(uint32_t fs)
{
    unsigned i;
    if(resource_fault) {board_divisor=SAMPLE_SOURCE_HZ/INITIAL_FS;board_fault=resource_fault;return;}
    capture_stop();
    board_fault=board_captured=board_copy_max=consumed=0;
    if(fs<MIN_FS) fs=MIN_FS;
    if(fs>MAX_FS) fs=MAX_FS;
    board_divisor=(SAMPLE_SOURCE_HZ+fs/2)/fs;
    if(board_divisor>65536UL) board_divisor=65536UL;
    if(board_divisor<2) board_divisor=2;
    SampClock_SetDividerRegister((uint16)(board_divisor-1),1);
    expected_block_cycles=(uint32_t)(((uint64_t)CPU_HZ*128*board_divisor)/SAMPLE_SOURCE_HZ);
    if(HI16((uint32)&dma_ring[0][0])!=
       HI16((uint32)&dma_ring[DMA_RING_BLOCKS-1][127])) {board_fault|=4;return;}
    for(i=0;i<DMA_RING_BLOCKS;i++) {
        if(CyDmaTdSetConfiguration(td[i],256,td[(i+1)%DMA_RING_BLOCKS],
                    TD_INC_DST_ADR | DMA_ADC__TD_TERMOUT_EN)!=CYRET_SUCCESS)
            board_fault|=8;
        if(CyDmaTdSetAddress(td[i],LO16((uint32)ADC_DMA_RESULT_PTR),
                   LO16((uint32)&dma_ring[i][0]))!=CYRET_SUCCESS) board_fault|=8;
    }
    if(CyDmaChSetInitialTd(dma_channel,td[0])!=CYRET_SUCCESS) board_fault|=8;
    if(board_fault) return;
    isr_dma_ClearPending(); isr_dma_Enable();
    CyDmaClearPendingDrq(dma_channel);
    if(CyDmaChEnable(dma_channel,1)!=CYRET_SUCCESS) {board_fault|=8;return;}
    last_dma_tick=board_cycles();
    SampClock_Start();
}
int board_read_block(uint16_t out[128],uint32_t *sequence,uint32_t *skipped)
{
    uint32_t count,chosen,start,duration;
    unsigned i,index;
    uint8 state;
    if(resource_fault || board_fault) {board_fault|=resource_fault;SampClock_Stop();return 0;}
    /* Detect missing block interrupts instead of freezing the last valid graph. */
    if((uint32_t)(board_cycles()-last_dma_tick)>expected_block_cycles*3) {
        board_fault|=32; SampClock_Stop(); return 0;
    }
    if(board_captured==consumed) return 0;
    state=CyEnterCriticalSection();
    start=board_cycles(); count=board_captured;
    /* Consume in order while there are at most two ready blocks. If behind,
       take the newest and report every omitted block. Four DMA slots provide
       overwrite slack; copying is required to take < 1/4 of one block period. */
    chosen=(uint32_t)(count-consumed)<=2 ? consumed+1 : count;
    index=(unsigned)((chosen-1)&3UL);
    for(i=0;i<128;i++) {
        int32_t v=(int32_t)dma_ring[index][i]+raw_correction;
        if(v<0 || v>4095) {board_fault|=16;v=0;}
        out[i]=(uint16_t)v;
    }
    duration=board_cycles()-start;
    if(duration>board_copy_max) board_copy_max=duration;
    if(duration>=expected_block_cycles/4) board_fault|=2;
    *skipped=chosen-consumed-1; consumed=chosen; *sequence=chosen;
    CyExitCriticalSection(state);
    if(board_fault) {SampClock_Stop();return 0;}
    return 1;
}
void board_init(void)
{
    unsigned i;
    int16 raw,api;
    REG32(0xe000edfcUL)|=1UL<<24; /* CoreDebug DEMCR: enable trace */
    DWT_CYCCNT=0; REG32(0xe0001000UL)|=1; /* DWT CTRL CYCCNTENA */
    last_tick=board_cycles();
    SampClock_Stop();
    ADC_SAR_Start();
    ADC_SAR_IRQ_Disable(); /* DMA, not a CPU interrupt for every sample */
    CyDelayUs(20);
    /* Probe the generated 12-bit API's additive raw offset. Keep ADC hardware
       triggering selected; do not call StartConvert() in this mode. */
    SampClock_Start(); CyDelay(2); SampClock_Stop(); CyDelayUs(20);
    raw=(int16)CY_GET_REG16(ADC_DMA_RESULT_PTR);
    api=ADC_SAR_GetResult16();
    raw_correction=(int32_t)api-raw;
    dma_channel=DMA_ADC_DmaInitialize(2,1,HI16((uint32)ADC_DMA_RESULT_PTR),
                                    HI16((uint32)&dma_ring[0][0]));
    for(i=0;i<DMA_RING_BLOCKS;i++) {
        td[i]=CyDmaTdAllocate();
        if(td[i]==CY_DMA_INVALID_TD) resource_fault|=8;
    }
    isr_dma_StartEx(dma_complete); isr_dma_SetPriority(0); isr_dma_Disable();
#if USE_USB_CDC
    USBFS_Start(0,USBFS_5V_OPERATION);
#else
    UART_Start();
#endif
}
void board_transport_poll(void)
{
#if USE_USB_CDC
    static uint8 configured;
    unsigned n;
    if(USBFS_IsConfigurationChanged()) {
        configured=USBFS_GetConfiguration()!=0;
        if(configured) USBFS_CDC_Init();
        tx_length=tx_offset=0;
    }
    if(configured && tx_offset<tx_length && USBFS_CDCIsReady()) {
        n=tx_length-tx_offset; if(n>64) n=64;
        USBFS_PutData(tx+tx_offset,(uint16)n); tx_offset+=n;
    }
#else
    unsigned budget=4;
    while(budget-- && tx_offset<tx_length &&
          (UART_ReadTxStatus() & UART_TX_STS_FIFO_NOT_FULL))
        UART_PutChar(tx[tx_offset++]);
#endif
}
int board_rx_byte(void)
{
#if USE_USB_CDC
    static uint8 rx[64]; static unsigned pos,len;
    if(pos==len) {
        if(!USBFS_GetConfiguration() || !USBFS_DataIsReady()) return -1;
        len=USBFS_GetAll(rx); pos=0;
    }
    return pos<len?rx[pos++]:-1;
#else
    return UART_GetRxBufferSize()?(int)UART_GetChar():-1;
#endif
}
int board_send(const uint8_t *data,unsigned length)
{
    if(tx_offset<tx_length || length>sizeof(tx)) return 0;
    memcpy(tx,data,length); tx_length=length;tx_offset=0;return 1;
}
