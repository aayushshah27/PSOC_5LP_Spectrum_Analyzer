#include "wire.h"
uint32_t wire_crc32(const uint8_t *p, unsigned n)
{
    uint32_t c=0xffffffffUL;
    unsigned i;
    while(n--) {
        c^=*p++;
        for(i=0;i<8;i++) c=(c>>1)^((0UL-(c&1UL))&0xedb88320UL);
    }
    return ~c;
}
static void u32(uint8_t *p,uint32_t n)
{ p[0]=(uint8_t)n; p[1]=(uint8_t)(n>>8); p[2]=(uint8_t)(n>>16); p[3]=(uint8_t)(n>>24); }
void wire_pack(uint8_t *p,const uint32_t m[WIRE_FIELDS],const uint32_t a[65])
{
    unsigned i;
    p[0]='P';p[1]='S';p[2]='A';p[3]='1'; p[4]=1;p[5]=1;
    p[6]=(uint8_t)WIRE_SIZE;p[7]=(uint8_t)(WIRE_SIZE>>8);
    for(i=0;i<WIRE_FIELDS;i++) u32(p+8+4*i,m[i]);
    for(i=0;i<65;i++) u32(p+8+4*WIRE_FIELDS+4*i,a[i]);
    u32(p+WIRE_SIZE-4,wire_crc32(p,WIRE_SIZE-4));
}
