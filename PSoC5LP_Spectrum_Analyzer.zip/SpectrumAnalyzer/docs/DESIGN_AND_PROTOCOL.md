# Design, fixed-point arithmetic and protocol

## Data path

ADC_SAR eoc requests a DMA burst of 2 bytes into the current 128-sample slot.
Four transfer descriptors form a cyclic chain, each pointing to a separate slot.
TD preservation is enabled so a revisited descriptor restarts at its original
address/count. Terminal output signals one block interrupt, not 128 sample IRQs.
The ISR publishes a monotonically increasing completion sequence and checks cadence.

Main consumes ready blocks in order with at most two pending. If more have
accumulated, it takes the latest completed block and accounts for omitted blocks.
It copies into a private processing buffer inside a short critical section; DMA
continues independently. With four slots and the enforced copy duration below
one quarter of a block period, the selected source is separated from the DMA
writer under the checked ISR-latency assumptions. Main does not process a live
DMA buffer in place. Late/missing/coalesced block IRQs are treated as faults.
The runtime checks are conservative; verify the assumptions on the actual board,
particularly interrupt latency, DMA bank placement and one EOC per trigger.

Processing order:

1. Decode the ADC's 12-bit single-ended result into counts 0–4095.
2. Stateful fixed-point LPF or bypass. Preserve filter state across adjacent blocks.
3. Remove the block's mean and convert to Q3 ADC counts (counts times 8).
4. Multiply by a Q15 window; round using explicit signed arithmetic.
5. Bit-reverse and execute a radix-2, 7-stage complex FFT for 128 real inputs.
6. Integer square root of 64-bit squared magnitudes.
7. Normalize to single-sided peak ADC counts in Q16; do not double Nyquist.
8. Mark settling/clipping/gaps and update the MCU generation/valid counters.
9. Serialize selected display snapshots in main; service TX without waiting for bytes.

There are no floating-point types, trig functions, or float FFT operations in the
MCU sources. Tables are generated once by a development script and included as
constants. PC axis/voltage rendering and coefficient calculation can use floats.

## Scaling and numerical range

A 12-bit input or its first-order filtered output remains in [0,4095]. After mean
removal and multiplication by 8, absolute sample magnitude is <=32760, apart from
rounding by at most a small fraction of a count. The largest window coefficient
has magnitude <=1. A conservative FFT component bound is approximately
`128*32768`, which fits int32. Twiddle products and sum/difference products use
int64 before Q15 rounding. The squared magnitudes fit comfortably in uint64.
No stage-by-stage division is used, preserving precision for low-level tones.
This design makes that headroom explicit rather than relying on int16 overflow.

If integer FFT magnitude is M and Q15 coefficients sum to S, then:

`A_counts = 2*M / (8 * S/32768)`

`A_counts_Q16 = M * 536870912 / S`

Use half that factor for DC/Nyquist. DC is then explicitly set to zero because
its block mean was intentionally removed. A periodic flat-top window's coherent
gain is approximately 0.21558; using its actual quantized coefficient sum corrects
that loss. Unity Q15 coefficients are 32767, not 32768; normalization handles it.

The PC converts `A_counts_Q16 / 65536 * full_scale_volts / 4096 * gain_calibration`.
Amplitude is V peak. For a sine, Vpp=2*Vpeak and Vrms=Vpeak/sqrt(2). Do not reuse
that RMS relationship indiscriminately for arbitrary waveforms.

LPF state is ADC-count Q16, alpha is Q30, and update products use int64. Alpha=0
means bypass; otherwise the board accepts [262144,1073741824], equivalent to
[1/4096,1]. On reset it seeds state from the first sample. At least ceil(10/alpha)
samples are marked as settling. If any samples in a frame are settling, the whole
frame is flagged and excluded from valid counts. No FFT-window compensation is
used to cancel the intentional frequency response of the LPF.

## Counter and timing definitions

| Counter/field | Meaning |
|---|---|
| epoch | Incremented on rate/window/filter/reset commands |
| frame | Complete FFT + magnitude arrays generated in this epoch |
| capture | Capture sequence associated with the last processed frame |
| captured | DMA blocks completed so far in this epoch |
| valid | Generated frames without settling, ADC clipping or acquisition fault |
| skipped | Completed ADC blocks omitted from processing |
| tx_dropped | Display snapshots not queued because TX was occupied |
| elapsed_ms | On-chip elapsed time since epoch restart, from DWT cycles |
| dsp_cycles | Last DSP elapsed cycles, including preempting interrupts/GPIO overhead |
| max_dsp_cycles | Maximum DSP duration this epoch |
| max_copy_cycles | Maximum critical copy duration this epoch |
| raw_min/raw_max | Minimum/maximum ADC counts in the last processed block |
| command_errors | Invalid commands since boot, not cleared by a measurement reset |

DWT is initialized directly on the Cortex-M3. Main accumulates unsigned 32-bit
cycle-counter differences into a uint64 total, then divides by CPU_HZ/1000.
At 80 MHz, DWT wraps about every 53.7 s; main must run more frequently than that,
which it does in normal operation. Do not benchmark while halted at breakpoints,
in sleep or after changing the CPU clock without updating configuration.
Elapsed_ms wraps after about 49.7 days; benchmark runs are much shorter.

The GUI's conservative epoch-average rate is `1000*valid/elapsed_ms`.
The CLI's interval rate is `delta(valid)/(delta(elapsed_ms)/1000)`.
Neither uses the number of received packets as the PSoC spectrum update rate.
The sampling rate is reported as the rational `clock_hz/divisor`, avoiding a
rounded-frequency-axis error. Clock-source calibration remains a hardware task.

## Binary frame v1

Each frame is **368 bytes**. All integer fields are uint32 little endian unless
otherwise specified. Never send a raw C struct; `wire_pack()` explicitly serializes.

| Byte range | Contents |
|---|---|
| 0–3 | ASCII `PSA1` |
| 4 | Version 1 |
| 5 | Type 1: spectrum/status snapshot |
| 6–7 | Total frame length uint16 =368 |
| 8–103 | 24 metadata fields below, each uint32 |
| 104–363 | 65 amplitude values in ADC-count Q16 |
| 364–367 | CRC32 of bytes 0–363, IEEE reflected polynomial 0xEDB88320 |

Metadata field order (also defined by `wire.h` and `pc/protocol.py`):

0 epoch, 1 frame, 2 capture, 3 clock_hz, 4 divisor, 5 elapsed_ms, 6 valid,
7 captured, 8 skipped, 9 tx_dropped, 10 fault, 11 clipped, 12 dsp_cycles,
13 max_dsp_cycles, 14 max_copy_cycles, 15 window, 16 alpha, 17 warm,
18 command_errors, 19 raw_min, 20 raw_max, 21 cpu_hz, 22 flags, 23 window_sum.

`clipped` is the number of samples <=4 or >=4091 in the last raw block.
`warm` is the remaining filter warmup sample count. `flags` bit0 means the last
frame contained settling samples, bit1 clipping, bit2 a capture gap before it.
`fault` bit masks are documented in README. Before the first processed frame,
amplitudes and related fields are zero; frame=0 signals that state.

The parser accepts fragmented input, searches for magic, checks version/length
and CRC, and resynchronizes after corruption. No CRC is omitted for performance.
The UART transmitter queues at most one snapshot; an active frame is immutable.
The GUI reader thread decodes data independently of rendering; it may discard
old display updates if the UI falls behind, without changing MCU counters.

## PC-to-board commands

ASCII, newline terminated, no checksum. These short local-control messages are
validated before applying. Each successful setting command begins a new epoch.
There is no separate textual ACK; a CRC-checked frame echoes the accepted config.

| Command | Action |
|---|---|
| `S 32000` | Request Fs in [2000,500000]; nearest clock divider selected; LPF bypassed |
| `W 0` | Rectangular window |
| `W 1` | Flat-top window (default) |
| `W 2` | Hann window |
| `F 0` | Bypass LPF |
| `F <alpha_Q30>` | Set fixed-point coefficient; PC computes it from cutoff and echoed Fs |
| `R` | Restart measurement/acquisition with current settings |

All commands stop the sampling clock, drain an in-flight conversion, disable DMA,
clear pending requests, restore descriptors and restart. These configuration gaps
are outside a continuous measurement epoch. No sample-rate change is disguised as
contiguous sampling. Filter state is reset on changes or reported input gaps.
Long/malformed lines increment command_errors and are rejected.

## Optimizations left for measured iteration

The initial implementation prioritizes portable integer correctness. The complex
FFT uses real-valued input but does not exploit a specialized 64-complex real FFT.
Per-bin integer square root/division, bitwise CRC and buffer copies have measurable
costs. Do not present this baseline as a proven maximum-performance solution.
Measure on your actual board before specializing. Any faster FFT, lookup square
root, transport change or reduced precision needs the same accuracy checks.
