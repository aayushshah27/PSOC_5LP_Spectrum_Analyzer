# Hardware bring-up and demonstration

## Input wiring and first run

Use a bench function generator and a scope for the initial demonstration. With the
specified single-ended ADC range, the analog input must stay **between 0 and
2.048 V**, and also inside the device's supply rails. Negative signals need biasing.

| Connection | Destination |
|---|---|
| Generator signal | `Signal_In`, P0[0] |
| Generator ground | Board GND |
| Scope input | P0[0], with ground at board GND |
| Programming / default PC serial | KitProg USB connector |

Start with a sine wave at **3 kHz**, **0.8 Vpp**, **+1.024 V DC offset**. That means
approximately 0.624–1.424 V at the ADC, with **0.4 V peak** AC amplitude. Confirm
those voltages with the scope at the input pin before connecting/recording results.
A generator's amplitude can differ by a factor of two depending on its 50-ohm vs
Hi-Z load setting. The ADC input is not a 50-ohm termination. Use a low-impedance
source compatible with the SAR acquisition time.

The generator's offset is an easy lab bias source. A future external front end
can use AC coupling, a buffered bias and analog anti-alias filtering; this package
does not include or certify an analog front-end circuit. Avoid arbitrary extra
RC filtering if you have not included its passband attenuation in the reference.
Use band-limited inputs when testing the ADC; high harmonics of square waves can
alias and change the measured sampled waveform spectrum.

## Confirm the ADC data format and scale first

With the FFT running, use safe DC levels near 0.25, 1.00 and 1.75 V. In the debugger,
inspect the latest `raw[]` values in main.c, or the PC frame's raw_min/raw_max fields.
Expected counts are approximately `V / 2.048 * 4096`. The spectrum of DC should
be near zero because the block mean is removed. This confirms acquisition even
when the graph has no nonzero tone. Do not use rail-clipped DC for performance.

The DMA stores the hardware working register as signed 16-bit values. Startup
compares that register with the generated `ADC_SAR_GetResult16()` to derive the
API's additive offset. This assumes the specified 12-bit mode; if raw/API values
are not related by a fixed offset on your installed component version, match the
conversion in that generated API before continuing. A plausible graph alone is
not proof that raw coding is correct.

In the app set ADC full-scale to 2.048 V for the prescribed reference setup. Do
not substitute the 5-V supply voltage. If using a different ADC input range, change
both the hardware configuration and full-scale field, then repeat the DC checks.

## Accuracy measurements

At nominal Fs=32 kHz, bin spacing is 250 Hz. Test LPF bypass, flat-top default,
and allow the displayed hardware configuration to settle after changes.

| Test | Example signal | Check |
|---|---|---|
| Coherent sine | 3,000 Hz, 0.4 V peak | Peak near bin 12, amplitude 0.36–0.44 V |
| Off-bin sine | 3,087.5 Hz, 0.4 V peak | Frequency within 250 Hz; amplitude within ±10% |
| Second tone | 7,775 Hz, 0.2 V peak | Same accuracy checks |
| Two tones | 3,087.5 Hz at 0.3 V peak + 7,775 Hz at 0.18 V peak | Both peaks within tolerances; sum does not clip |
| Frequency sweep | Several separated frequencies in bins 6–58 | Repeat at several amplitudes and phases |
| Square / triangle | Low-frequency, DC-biased waveform | Compare significant sampled harmonics, accounting for analog bandwidth and aliasing |

For two tones use a generator with arbitrary-waveform/summing capability or a
proper summing circuit. Do not directly connect two generator outputs together.
The reference amplitude is the actual component amplitude at the ADC input, not
merely a generator menu setting. Use a calibrated scope FFT or known source/sum
when necessary. The PC's CSV records all bins and calibration settings.

Flat-top creates a broad group of high neighboring bins from one tone. They are a
single windowed main lobe, not separate physical tones. Peak readout groups such
lobes. Its separation rule is a convenience for isolated tones, not a general
multi-tone identification algorithm. Use wider tone spacing for the amplitude
demonstration. For close tones, discuss the 128-sample resolution/window tradeoff.

For each true tone record:

`amplitude error (%) = 100 * (displayed_Vpeak - reference_Vpeak) / reference_Vpeak`

`frequency error (bins) = (displayed_Hz - reference_Hz) / (measured_Fs / 128)`

Pass: absolute amplitude error <=10%, absolute frequency error <=1 bin. Use peak
rather than RMS amplitude consistently. The displayed frequency readout uses local
parabolic interpolation; the graph itself contains the actual 65 FFT bins.

### Gain calibration

Use a coherent, isolated, well-resolved sine with LPF bypass. If the scope reads
0.400 V peak and the app reads 0.388 V peak with gain=1, enter gain=0.400/0.388.
Keep the same calibration for all tests; do not calibrate each tone independently.
Retest other frequencies and amplitudes. A calibration cannot fix clipping,
aliasing, a wrong frequency axis or frequency-dependent front-end attenuation.

## LPF demonstration

1. Keep the two-tone input present, e.g. 3,087.5 Hz and 7,775 Hz.
2. Save a bypass spectrum CSV/screenshot.
3. Enable LPF, enter cutoff **3,000 Hz**, Apply settings.
4. Wait for the settling warning to clear; compare both tone amplitudes.
5. Change cutoff to **6,000 Hz**, Apply and compare again.
6. Disable LPF and show recovery to the bypass spectrum.

The one-pole transfer function is `H(z)=alpha / (1-(1-alpha)z^-1)`.
For `d=1-cos(2*pi*fc/Fs)`, the PC computes
`alpha=sqrt(d*d+2*d)-d`, quantized to Q30. This sets the **discrete-time** -3-dB
cutoff, rather than using an approximate analog mapping near Nyquist. The board
applies only fixed-point recurrence arithmetic; no float/trig runs on the MCU.

When checking filtered amplitudes, the expected reference is the input component
amplitude multiplied by `abs(H(exp(j*2*pi*f/Fs)))`. Attenuation is the desired filter
effect, not a spectrum calibration error. Cutoff must be positive, below Nyquist,
and high enough for the supported coefficient resolution. Sample-rate changes
bypass/reset the filter; Apply settings recomputes the cutoff for the echoed Fs.

## Performance measurement

Connect a scope/logic analyzer to:

| Pin | Purpose |
|---|---|
| P2[1] `Probe_Sample` | Actual sample-trigger clock; count rising edges |
| P2[2] `Probe_EOC` | ADC conversion completion; check no missed triggers |
| P2[0] `Probe_FFT` | High during processing; falling edge marks end of DSP for one generated spectrum |

The PSoC counters are the primary generation-rate measurement. `Probe_FFT` pulses
provide an independent visualization; use only after settling with an unclipped
signal and no faults/skips. Probe width is nearly DSP execution time; the internal
timing also includes the GPIO API overhead and any interrupts during that interval.
The maximum processing time can be compared with `128/Fs` to understand headroom.

1. Validate DWR clock macros against actual clock configuration and scope traces.
2. Keep an unclipped signal connected. Disconnect the GUI from the COM port.
3. From `pc`, run:
   ```text
   python benchmark.py --port COM5 --rates 32000 64000 128000 256000 --seconds 15 --output benchmark.csv
   ```
4. Optionally repeat with `--cutoff 3000` to measure the bonus filter configuration.
5. Review every row. A continuity FAIL, nonzero acquisition skips, clipping or
   faults disqualifies that rate as uninterrupted operation.
6. Repeat amplitude/frequency tests at the highest passing operating point.
7. Run a longer test (e.g. 60 s) at the selected point. Record measured actual Fs,
   valid spectrum count difference and on-chip elapsed-time difference.
8. Compute score = actual Fs * valid spectra/s. If using the script's nominal Fs,
   label it nominal and first verify its clock accuracy with the scope.

The script consumes PSoC-generated counters; it does not time GUI refresh or
recompute spectra. A few counter-boundary differences are possible because a
block can be in flight at either endpoint; no skipped-block count is permitted
for a sustained continuity PASS. The script does not certify analog accuracy.

The four-slot ring permits acquisition while computing. If processing falls
behind, omitted blocks are counted and LPF state is reset. Clock/IRQ timing
faults stop sampling. Lower the rate and reset; do not hide these conditions.
To raise performance after a working baseline: measure DSP/CRC/transport costs,
compare compiler optimizations, keep ISRs short, specialize the real-input FFT
or integer-magnitude implementation, and retest accuracy after each optimization.
Do not claim the highest rate merely because the ADC can produce samples there.

## Final recording and handoff

Record a short sequence: single tone -> off-bin tone -> two tones -> LPF cutoff
changes -> benchmark results with independent scope timing. Fill
MEASUREMENT_SHEET.csv with real measurements and save screenshots/CSV files.
No hardware values in this package are presented as measured results.

Archive the actual Creator workspace and PC app after a teammate has rebuilt it
from a fresh extracted copy. Include firmware configuration, component versions,
clock report, selected transport and reproducible commands in the final README.
