# Primary hardware references

Use the datasheet shipped with your installed component version for exact APIs.
These links supplied hardware/API facts, not an externally copied FFT implementation.
The DSP, framing and app in this package were written for this deliverable.

- [CY8CKIT-059 official product page](https://www.infineon.com/evaluation-board/CY8CKIT-059): target board, Creator support, KitProg and target USB connectivity. Follow its kit guide for header/bridge connections.
- [ADC_SAR v3.0 component datasheet](https://www.infineon.com/assets/row/public/documents/cross-divisions/396/infineon-component-adc-sar-adc-sar-v3.0-software-module-datasheets-en.pdf): trigger/EOC interfaces, result API, reference options, ADC clock and conversion constraints.
- [DMA v1.70 component datasheet](https://www.infineon.com/assets/row/public/documents/cross-divisions/396/infineon-component-direct-memory-access-v1.70-software-module-datasheets-en.pdf): descriptor/channel APIs, preservation of cyclic descriptors and clearing pending hardware requests.
- [USBFS v2.11 component datasheet](https://www.infineon.com/assets/row/public/documents/cross-divisions/396/infineon-component-usbfs-v2.11-software-module-datasheets-en.pdf): optional CDC APIs and endpoint-memory-management restrictions.

CMSIS-DSP was considered but is not used; no CMSIS DSP installation or version
selection is needed for the supplied original FFT. Creator's generated peripheral
code remains subject to its normal tool/component licensing.
