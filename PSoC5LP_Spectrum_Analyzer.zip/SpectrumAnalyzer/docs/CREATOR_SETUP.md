# PSoC Creator setup — do this before building the firmware

## 1. New project and clocks

Create an Empty PSoC 5LP design named `SpectrumAnalyzer` for **CY8C5888LTI-LP097**
(the CY8CKIT-059 target). Use Creator 4.4 and ARM GCC; no FreeRTOS or CMSIS DSP is
needed. Keep your old RTOS workspace separate.

In Design Wide Resources -> Clocks, configure CPU/BUS_CLK to **80 MHz**, within the
part's permitted clock configuration. Inspect the build's actual clock report.
`CPU_HZ` and `SAMPLE_SOURCE_HZ` in `firmware/config.h` must equal the actual CPU
and sample-clock source frequencies. They are not automatically read from DWR.
If a timing constraint requires a lower BUS_CLK, update both macros as applicable.

Create the components below, with EXACT case-sensitive instance names. Depending
on your installed component version, UI wording may differ. Check each component's
local datasheet and generated header if Creator reports an API difference.

## 2. Components and configuration

| Component | Instance | Settings |
|---|---|---|
| Analog input Pin | `Signal_In` | One pin, analog, High-Z Analog, no digital input buffer |
| ADC_SAR | `ADC_SAR` | 12-bit, single ended **0–2.048 V**, **Hardware trigger**, internal ADC clock; configure high conversion capability with bypassed reference; generated actual ADC clock must be <=18 MHz |
| Digital Clock | `SampClock` | NEW clock with software API, BUS_CLK source, initial divider 2500 at 80 MHz =32 kHz; do not select an Existing clock alias |
| DMA | `DMA_ADC` | Hardware DRQ enabled, one 2-byte burst per request, source fixed, destination increment; expose/enable `nrq` terminal output; level-sensitive DRQ is appropriate for SAR EOC |
| Interrupt | `isr_dma` | Rising-edge, priority 0; connected to DMA terminal output, not to every ADC EOC |
| UART | `UART` | Full duplex, 115200, 8 data bits, no parity, 1 stop, TX buffer **4**, RX buffer **128**; no flow control; internal clock |
| Digital output Pin | `UART_TX` | Strong drive, hardware connection enabled |
| Digital input Pin | `UART_RX` | Digital input, high impedance, hardware connection enabled |
| Digital output Pin | `Probe_FFT` | Strong drive; **hardware connection disabled**, software Write API |
| Digital output Pin | `Probe_Sample` | Strong drive, hardware connection enabled |
| Digital output Pin | `Probe_EOC` | Strong drive, hardware connection enabled |

For ADC_SAR version 3.x, the 1 MS/s setting is a conversion capability setting,
not the actual stream sampling rate. BUS_CLK=80 MHz may yield a rounded ADC clock
such as 16 MHz. Hardware-trigger conversion takes longer than a free-running
conversion. Leave enough time for acquisition/conversion at the requested Fs.
Start at 32 kHz. With a bypassed internal reference, configure the ADC bypass pin
for SAR0 or SAR1 as assigned by Creator and fit the capacitor required by the
component/board documentation. Do not assume the board already has that capacitor.
An example starting value is 100 nF to analog ground; check the fitted SAR block
and kit schematic before connecting. P0[4] and P0[2] are reserved choices for
SAR0/SAR1 reference bypass, so the signal input below uses P0[0].

If your DMA dialog offers terminal output selection, enable `nrq`/TermOut0 so
`DMA_ADC__TD_TERMOUT_EN` is generated. **Do not use the DMA Wizard to generate a
second initialization routine.** `board.c` owns the four descriptors and the
cyclic chain, with TD preservation enabled. Do not add `TD_AUTO_EXEC_NEXT`: each
sample must wait for its own ADC EOC request. Generated `DMA_ADC_dma.h` must be
included through Creator's generated `project.h`.

## 3. Schematic connections

| From | To |
|---|---|
| `Signal_In` | `ADC_SAR` positive input |
| `SampClock` | `ADC_SAR.soc` |
| `SampClock` | `Probe_Sample` |
| `ADC_SAR.eoc` | `DMA_ADC.drq` |
| `ADC_SAR.eoc` | `Probe_EOC` |
| `DMA_ADC.nrq` | `isr_dma` |
| `UART.tx` | `UART_TX` |
| `UART_RX` | `UART.rx` |

`Probe_FFT` is software driven and has no schematic input wire. The clock should
produce one ADC trigger per rising edge. The SAR's trigger pulse-width and
synchronization rules must be respected. Use a common stable clock source and
check the ADC's generated clock. If your clock combination causes trigger jitter,
choose a sample-clock divider that is an integer multiple of the ADC-clock divider
and verify sample-to-EOC timing. Sampling clocks and EOC frequencies should agree.

## 4. DWR pin assignments

| Signal | Pin |
|---|---|
| `Signal_In` | P0[0] |
| `UART_TX` | P12[7] — target TX toward KitProg RX |
| `UART_RX` | P12[6] — target RX from KitProg TX |
| `Probe_FFT` | P2[0] |
| `Probe_Sample` | P2[1] |
| `Probe_EOC` | P2[2] |
| ADC reference bypass | Creator-assigned SAR0 P0[4] or SAR1 P0[2], matching fitted block |

If the snap-away KitProg portion was removed, provide the appropriate programmer,
serial adapter and power connections yourself. UART logic levels must match the
board's VDDIO. Connect grounds.

## 5. Add sources and build

1. Generate Application once so the peripheral headers exist.
2. Replace generated empty `main.c` with `firmware/main.c`.
3. Add `board.c`, `dsp.c`, `wire.c` to Source Files.
4. Add `board.h`, `config.h`, `dsp.h`, `wire.h`, `tables.h` to Header Files.
5. Keep all these files beside the project's `main.c`, or add their folder to the
   compiler's include path. Add files as project-owned relative files, not absolute
   references into a teammate's downloads folder.
6. Select C99 or GNU99. Initially use the default debug configuration; once working,
   use Release with `-O2`, then compare `-O3` using measurements. Do not assume that
   the higher optimization level is faster. No floating-point printf or libm is needed.
7. Build. Program. Inspect generated ADC `GetResult16()` and verify the peripheral
   result pointer macro `ADC_SAR_SAR_WRK_PTR` in `config.h`. The adapter probes the
   additive offset used by the 12-bit API. If your version transforms the raw data
   beyond an additive offset, adjust `board.c` decoding to match that generated API.
8. Perform the DC/raw checks in HARDWARE_AND_DEMO.md before trusting an FFT plot.

Never import `tests/stubs/project.h` into Creator. It is intentionally fake and
only supports a host C syntax check. No HEX is included because the real peripheral
configuration has not been generated and built here.

## 6. Optional target USB CDC (after UART works)

The default app communicates through KitProg's UART bridge. For the USB alternative,
use the **target micro-USB connector**, separate from the KitProg programming USB.
Add a `USBFS` component instance with that exact name. Use Creator's **CDC descriptor
template**, enable the CDC class APIs, and choose manual endpoint-buffer management
compatible with the CDC APIs. Configure its required USB clock and supply operation.
Do not enable automatic-memory-management DMA for these high-level APIs.

Set `USE_USB_CDC` to 1 in `config.h`; rebuild. `board.c` contains the CDC branch and
uses `USBFS_5V_OPERATION`, appropriate only for the corresponding supply setup;
select the other generated operating-voltage macro if your board is powered at
3.3 V. The graph uses the new COM port. The baud parameter is ignored by native
USB CDC transport. The UART components can remain on the schematic initially.
Increase the snapshot rate only after sustained USB transfers are verified.

## Integration status

- Portable DSP and wire code: host compiled and numerically tested.
- Board adapter and both transport branches: C syntax checked against fake headers.
- Generated Creator project, fitter, actual APIs and board operation: **not yet tested**.
- Scope/analog measurements and maximum supported rate: **not yet measured**.

Official references are in SOURCES.md. Prefer your locally installed component
version's datasheet when exact API names/settings differ.
