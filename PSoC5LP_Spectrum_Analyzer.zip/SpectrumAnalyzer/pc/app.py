"""Run: python app.py. Hardware-free graph: python app.py --demo."""
import argparse
import csv
import json
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import serial
from serial.tools import list_ports
from protocol import Parser,Frame,KEYS
from analysis import alpha_for_cutoff,voltages,peaks

class App:
    def __init__(self,root,demo=False):
        self.root=root; self.demo=demo;self.link=None;self.worker=None
        self.messages=queue.Queue(maxsize=8);self.stop=threading.Event()
        self.parser=Parser();self.latest=None;self.demo_count=0;self.error=''
        self.demo_start=time.monotonic()
        root.title('PSoC 5LP | Spectrum Analyzer');root.geometry('1180x800')
        root.configure(bg='#101827')
        style=ttk.Style();style.theme_use('clam')
        style.configure('.',background='#101827',foreground='#e2e8f0',fieldbackground='#1e293b')
        style.configure('TButton',padding=7,background='#24364b')
        style.configure('TEntry',fieldbackground='#1e293b',foreground='#e2e8f0')
        style.configure('TCombobox',fieldbackground='#1e293b',foreground='#e2e8f0')
        style.configure('Treeview',background='#182235',fieldbackground='#182235',foreground='#e2e8f0',rowheight=25)
        wrap=ttk.Frame(root,padding=16);wrap.pack(fill='both',expand=True)
        ttk.Label(wrap,text='SPECTRUM / 128',font=('Segoe UI',22,'bold')).pack(anchor='w')
        ttk.Label(wrap,text='Fixed-point PSoC processing · calibrated peak amplitudes · configurable input LPF').pack(anchor='w',pady=(3,12))
        row=ttk.Frame(wrap);row.pack(fill='x')
        self.port=tk.StringVar(); self.port_box=ttk.Combobox(row,textvariable=self.port,width=19)
        self.port_box.pack(side='left');ttk.Button(row,text='Refresh ports',command=self.refresh).pack(side='left',padx=5)
        self.connect_btn=ttk.Button(row,text='Connect',command=self.connect);self.connect_btn.pack(side='left')
        ttk.Button(row,text='Demo mode',command=self.toggle_demo).pack(side='left',padx=5)
        ttk.Button(row,text='Save spectrum CSV',command=self.save).pack(side='right')
        controls=ttk.Frame(wrap);controls.pack(fill='x',pady=12)
        self.fs=tk.StringVar(value='32000'); self.fc=tk.StringVar(value='3000')
        self.window=tk.StringVar(value='Flat-top (amplitude)');self.lpf=tk.BooleanVar(value=False)
        for label,var,width in [('Sampling Hz',self.fs,9),('LPF cutoff Hz',self.fc,9)]:
            ttk.Label(controls,text=label).pack(side='left',padx=(0,5))
            ttk.Entry(controls,textvariable=var,width=width).pack(side='left',padx=(0,12))
        self.window_box=ttk.Combobox(controls,textvariable=self.window,state='readonly',width=22,
             values=['Rectangular','Flat-top (amplitude)','Hann (resolution)'])
        self.window_box.pack(side='left',padx=5)
        ttk.Checkbutton(controls,text='Enable LPF',variable=self.lpf).pack(side='left',padx=7)
        ttk.Button(controls,text='Apply settings',command=self.apply).pack(side='left',padx=5)
        ttk.Button(controls,text='Reset measurement',command=lambda:self.send('R')).pack(side='right')
        cal=ttk.Frame(wrap);cal.pack(fill='x')
        self.full_scale=tk.StringVar(value='2.048');self.gain=tk.StringVar(value='1.0')
        for label,var in [('ADC full-scale V',self.full_scale),('Calibration gain',self.gain)]:
            ttk.Label(cal,text=label).pack(side='left',padx=(0,6))
            ttk.Entry(cal,textvariable=var,width=9).pack(side='left',padx=(0,14))
        self.stats=tk.StringVar(value='Connect the board or start the labeled simulation.')
        ttk.Label(wrap,textvariable=self.stats,font=('Consolas',10)).pack(anchor='w',pady=12)
        fig=Figure(figsize=(10,4),dpi=100,facecolor='#101827')
        self.axes=fig.add_subplot(111);self.axes.set_facecolor('#131f30')
        self.axes.tick_params(colors='#cbd5e1')
        for spine in self.axes.spines.values():spine.set_color('#334155')
        self.axes.set_xlabel('Frequency (Hz)',color='#cbd5e1');self.axes.set_ylabel('Amplitude (V peak)',color='#cbd5e1')
        self.axes.grid(True,color='#26374b',alpha=.7)
        self.curve,=self.axes.plot([],[],color='#38bdf8',linewidth=1.8,marker='.',markersize=4)
        fig.tight_layout()
        self.canvas=FigureCanvasTkAgg(fig,master=wrap);self.canvas.get_tk_widget().pack(fill='both',expand=True)
        self.table=ttk.Treeview(wrap,columns=('frequency','amplitude','bin'),show='headings',height=4)
        for col,title in [('frequency','Estimated frequency / Hz'),('amplitude','Amplitude / V peak'),('bin','Nearest peak bin')]:
            self.table.heading(col,text=title);self.table.column(col,width=230,anchor='center')
        self.table.pack(fill='x',pady=8)
        self.status=tk.StringVar(value='Flat-top readout assumes isolated tones. DC is removed. Inspect warnings before recording results.')
        ttk.Label(wrap,textvariable=self.status,wraplength=1100).pack(anchor='w')
        self.pending=None;self.last_draw=0
        self.refresh();root.protocol('WM_DELETE_WINDOW',self.close)
        root.after(50,self.tick)
    def refresh(self):
        ports=[p.device for p in list_ports.comports()];self.port_box['values']=ports
        if ports and not self.port.get():self.port.set(ports[0])
    def disconnect(self):
        self.stop.set()
        if self.worker:self.worker.join(timeout=.4)
        if self.link:self.link.close()
        self.link=None;self.worker=None;self.connect_btn.configure(text='Connect')
    def connect(self):
        if self.link:self.disconnect();return
        try:
            self.link=serial.Serial(self.port.get(),115200,timeout=.1,write_timeout=.3)
            self.link.reset_input_buffer();self.stop.clear();self.demo=False;self.parser=Parser()
            self.latest=None;self.pending=None
            self.worker=threading.Thread(target=self.reader,daemon=True);self.worker.start()
            self.connect_btn.configure(text='Disconnect');self.status.set('Connected. Waiting for a CRC-checked hardware frame.')
        except Exception as e:messagebox.showerror('Connection failed',str(e))
    def reader(self):
        while not self.stop.is_set():
            try:
                for frame in self.parser.feed(self.link.read(4096)):
                    try:self.messages.put_nowait(frame)
                    except queue.Full:
                        try:self.messages.get_nowait()
                        except queue.Empty:pass
                        try:self.messages.put_nowait(frame)
                        except queue.Full:pass
            except Exception as e:
                if not self.stop.is_set():self.error=str(e)
                return
    def toggle_demo(self):
        self.disconnect();self.demo=not self.demo;self.latest=None;self.pending=None
        self.demo_start=time.monotonic();self.demo_count=0
        self.status.set('SIMULATION: PC-generated tones and PC FFT. No hardware performance measurement.')
    def send(self,line):
        if self.demo:
            self.demo_start=time.monotonic();return
        if self.link:
            try:self.link.write((line+'\n').encode('ascii'))
            except Exception as e:messagebox.showerror('Command failed',str(e))
    def apply(self):
        try:
            fs=int(self.fs.get());fc=float(self.fc.get())
            if not 2000<=fs<=500000:raise ValueError('Sampling request must be 2000–500000 Hz. High rates need hardware qualification.')
            # Validate against actual rounded divider before issuing any commands.
            clock=self.latest.meta['clock_hz'] if self.latest and not self.demo else 80000000
            actual=clock/((clock+fs//2)//fs)
            alpha=alpha_for_cutoff(fc,actual) if self.lpf.get() else 0
            w=self.window_box.current()
            if self.demo:self.pending=None;return
            if not self.link:raise ValueError('Connect the board first, or choose Demo mode.')
            self.pending=(fs,w,fc,self.lpf.get(),time.monotonic())
            self.send('S '+str(fs))
            self.status.set('Applying sample rate; waiting for hardware confirmation before setting the LPF.')
        except Exception as e:messagebox.showerror('Settings',str(e))
    def demo_frame(self):
        fs=max(2000,int(self.fs.get()));n=np.arange(128)
        frequencies=[fs*12.35/128,fs*31.1/128]
        x=.32*np.sin(2*np.pi*frequencies[0]*n/fs)+.18*np.sin(2*np.pi*frequencies[1]*n/fs)
        windex=self.window_box.current();windex=max(0,windex)
        if self.lpf.get():
            aq=alpha_for_cutoff(float(self.fc.get()),fs)/(1<<30)
            # Steady-state sine response, including phase.
            x=np.zeros(128)
            for f,amp in zip(frequencies,[.32,.18]):
                h=aq/(1-(1-aq)*np.exp(-2j*np.pi*f/fs))
                x+=amp*abs(h)*np.sin(2*np.pi*f*n/fs+np.angle(h))
        if windex==0:w=np.ones(128)
        elif windex==2:w=.5-.5*np.cos(2*np.pi*n/128)
        else:w=.21557895-.41663158*np.cos(2*np.pi*n/128)+.277263158*np.cos(4*np.pi*n/128)-.083578947*np.cos(6*np.pi*n/128)+.006947368*np.cos(8*np.pi*n/128)
        a=2*np.abs(np.fft.rfft((x-x.mean())*w))/w.sum();a[0]=0;a[-1]/=2
        # Encode volts into nominal ADC-count Q16 so display follows the same conversion.
        full=float(self.full_scale.get());gain=float(self.gain.get())
        a=np.maximum(0,np.rint(a/full*4096/gain*65536)).astype(np.uint32)
        m=dict.fromkeys(KEYS,0);m.update(epoch=1,frame=self.demo_count,clock_hz=fs,divisor=1,
              cpu_hz=80000000,window=windex,raw_min=1000,raw_max=3000)
        self.demo_count+=1
        return Frame(m,tuple(map(int,a)))
    def draw(self,frame):
        self.latest=frame;m=frame.meta
        full=float(self.full_scale.get());gain=float(self.gain.get())
        if full<=0 or gain<=0:raise ValueError('Calibration values must be positive.')
        a=voltages(frame,full,gain);f=np.arange(65)*frame.fs/128
        self.curve.set_data(f,a);self.axes.set_xlim(0,frame.fs/2)
        self.axes.set_ylim(0,max(.02,float(a.max())*1.2));self.canvas.draw_idle()
        for item in self.table.get_children():self.table.delete(item)
        for frequency,amplitude,k in peaks(a,frame.fs,m['window']):
            self.table.insert('', 'end',values=(f'{frequency:.2f}',f'{amplitude:.5f}',k))
        if self.demo:
            self.stats.set(f'SIMULATION / PC FFT    Fs = {frame.fs:,.2f} Hz    Δf = {frame.fs/128:,.2f} Hz    Hardware rate / score: unavailable')
            return
        self.stats.set(f'Nominal Fs = {frame.fs:,.2f} Hz   Δf = {frame.fs/128:,.2f} Hz   MCU valid spectra/s = {frame.rate:,.1f}   Score = {frame.score:,.0f}\n'
                       f'Epoch {m["epoch"]} | Generated {m["frame"]} | Skipped {m["skipped"]} | TX snapshots missed {m["tx_dropped"]} | DSP {1e6*m["dsp_cycles"]/m["cpu_hz"]:.1f} µs | CRC errors {self.parser.bad_crc}')
        warnings=[]
        if m['fault']:warnings.append(f'ACQUISITION FAULT {m["fault"]}: see README; lower Fs / fix setup, then reset')
        if m['flags']&1 or m['warm']:warnings.append('LPF SETTLING — amplitude not yet valid')
        if m['clipped']:warnings.append('ADC CLIPPING — reduce signal amplitude or change bias')
        if m['skipped']:warnings.append('CAPTURE GAPS — this rate has not passed lossless operation')
        if m['command_errors']:warnings.append(f'Command errors: {m["command_errors"]}')
        if m['window']!=1:warnings.append('±10% off-bin amplitude is not guaranteed with this window')
        if m['flags']&4:warnings.append('Gap before this frame')
        self.status.set(' | '.join(warnings) or 'Hardware data. Flat-top amplitudes assume isolated tones away from DC/Nyquist. Score remains subject to accuracy validation.')
    def save(self):
        if not self.latest:return
        path=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('CSV','*.csv')])
        if not path:return
        try:
            a=voltages(self.latest,float(self.full_scale.get()),float(self.gain.get()))
            with open(path,'w',newline='') as file:
                file.write('# '+json.dumps({'simulation':self.demo,'full_scale_V':self.full_scale.get(),
                        'calibration_gain':self.gain.get(),'metadata':self.latest.meta})+'\n')
                writer=csv.writer(file);writer.writerow(['bin','frequency_hz','amplitude_v_peak'])
                writer.writerows((k,k*self.latest.fs/128,float(v)) for k,v in enumerate(a))
            self.status.set('Saved '+path)
        except Exception as e:messagebox.showerror('Save failed',str(e))
    def tick(self):
        try:
            frame=None
            while True:
                try:frame=self.messages.get_nowait()
                except queue.Empty:break
            if self.error:self.status.set('Serial error: '+self.error);self.error=''
            if self.demo:frame=self.demo_frame()
            if frame:
                if self.pending:
                    fs,w,fc,enabled,started=self.pending
                    requested_div=(frame.meta['clock_hz']+fs//2)//fs
                    if frame.meta['divisor']==requested_div:
                        self.send('W '+str(w));self.send('F '+str(alpha_for_cutoff(fc,frame.fs) if enabled else 0))
                        self.pending=None
                    elif time.monotonic()-started>5:
                        self.pending=None;self.status.set('Settings timed out. Check serial connection and firmware commands.')
                self.draw(frame)
        except Exception as e:self.status.set(str(e))
        self.root.after(50,self.tick)
    def close(self):
        self.disconnect();self.root.destroy()
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--demo',action='store_true');args=ap.parse_args()
    root=tk.Tk();App(root,args.demo);root.mainloop()
