"""Protocol v1: fixed length, little endian, CRC32, resynchronizing stream parser."""
from dataclasses import dataclass
import struct
import zlib
MAGIC=b'PSA1'
N=128
KEYS=('epoch frame capture clock_hz divisor elapsed_ms valid captured skipped '
      'tx_dropped fault clipped dsp_cycles max_dsp_cycles max_copy_cycles '
      'window alpha warm command_errors raw_min raw_max cpu_hz flags window_sum').split()
SIZE=8+4*len(KEYS)+65*4+4
@dataclass
class Frame:
    meta: dict
    amplitudes: tuple
    @property
    def fs(self):
        return self.meta['clock_hz']/self.meta['divisor']
    @property
    def rate(self):
        return 1000*self.meta['valid']/max(1,self.meta['elapsed_ms'])
    @property
    def score(self):
        return self.fs*self.rate
class Parser:
    def __init__(self):
        self.buffer=bytearray()
        self.bad_crc=0
        self.discarded=0
    def feed(self,data):
        self.buffer.extend(data)
        frames=[]
        while True:
            where=self.buffer.find(MAGIC)
            if where<0:
                keep=min(3,len(self.buffer))
                self.discarded+=len(self.buffer)-keep
                if keep: self.buffer=self.buffer[-keep:]
                else: self.buffer.clear()
                break
            if where:
                self.discarded+=where
                del self.buffer[:where]
            if len(self.buffer)<8: break
            version,kind,length=struct.unpack_from('<BBH',self.buffer,4)
            if (version,kind,length)!=(1,1,SIZE):
                del self.buffer[0];self.discarded+=1;continue
            if len(self.buffer)<SIZE: break
            packet=self.buffer[:SIZE]
            crc=struct.unpack_from('<I',packet,SIZE-4)[0]
            if (zlib.crc32(packet[:-4])&0xffffffff)!=crc:
                self.bad_crc+=1;del self.buffer[0];continue
            values=struct.unpack_from('<'+str(len(KEYS)+65)+'I',packet,8)
            meta=dict(zip(KEYS,values[:len(KEYS)]))
            if not meta['divisor'] or not meta['cpu_hz']:
                self.discarded+=SIZE
            else:
                frames.append(Frame(meta,values[len(KEYS):]))
            del self.buffer[:SIZE]
        return frames

def pack(meta,amplitudes):
    body=struct.pack('<4sBBH',MAGIC,1,1,SIZE)
    body+=struct.pack('<'+str(len(KEYS)+65)+'I',*(meta[k] for k in KEYS),*amplitudes)
    return body+struct.pack('<I',zlib.crc32(body)&0xffffffff)
