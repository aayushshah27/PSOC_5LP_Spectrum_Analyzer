import numpy as np

def alpha_for_cutoff(fc,fs):
    """Exact discrete-time -3 dB cutoff for y += alpha*(x-y)."""
    if not 0<fc<fs/2:
        raise ValueError('Cutoff must be above zero and below Nyquist.')
    d=1-np.cos(2*np.pi*fc/fs)
    alpha=float(np.sqrt(d*d+2*d)-d)
    q=round(alpha*(1<<30))
    if q<262144:
        raise ValueError('Cutoff too low for this fixed-point implementation.')
    return q

def voltages(frame,full_scale=2.048,gain=1.0):
    return np.asarray(frame.amplitudes,dtype=float)/65536*full_scale/4096*gain

def peaks(amplitudes,fs,window,limit=5):
    """Isolated-tone readout. Close tones require a different window/test setup."""
    a=np.asarray(amplitudes,dtype=float)
    threshold=max(float(a.max())*0.06,1e-9)
    candidates=[k for k in range(1,len(a)-1)
                if a[k]>=a[k-1] and a[k]>a[k+1] and a[k]>threshold]
    if a[-1]>a[-2] and a[-1]>threshold: candidates.append(len(a)-1)
    selected=[]
    separation=5 if window==1 else (2 if window==2 else 1)
    for k in sorted(candidates,key=lambda k:a[k],reverse=True):
        if all(abs(k-j)>separation for j in selected): selected.append(k)
        if len(selected)==limit: break
    result=[]
    for k in selected:
        delta=0.0
        if 0<k<len(a)-1:
            denom=a[k-1]-2*a[k]+a[k+1]
            if denom<0: delta=float(np.clip(0.5*(a[k-1]-a[k+1])/denom,-0.5,0.5))
        result.append(((k+delta)*fs/128,float(a[k]),k))
    return sorted(result,key=lambda r:r[0])
