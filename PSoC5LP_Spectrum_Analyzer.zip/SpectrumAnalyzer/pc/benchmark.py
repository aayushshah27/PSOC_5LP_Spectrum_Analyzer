"""Measure MCU counter deltas; this does not certify analog amplitude accuracy.
Example: python benchmark.py --port COM5 --rates 32000 64000 128000 --seconds 15
"""
import argparse,csv,time
from pathlib import Path
import serial
from protocol import Parser
from analysis import alpha_for_cutoff

def next_frame(link,parser,deadline):
    while time.monotonic()<deadline:
        for f in parser.feed(link.read(4096)):
            yield f

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--port',required=True)
    ap.add_argument('--baud',type=int,default=115200)
    ap.add_argument('--rates',type=int,nargs='+',default=[32000,64000,128000,256000])
    ap.add_argument('--cutoff',type=float,default=0,help='LPF cutoff in Hz; 0 bypasses the filter')
    ap.add_argument('--seconds',type=float,default=15)
    ap.add_argument('--output',default='benchmark.csv')
    args=ap.parse_args()
    if args.seconds<2:ap.error('Use at least 2 seconds per operating point.')
    rows=[]
    with serial.Serial(args.port,args.baud,timeout=.1,write_timeout=.5) as link:
        time.sleep(.3);link.reset_input_buffer();parser=Parser()
        for rate in args.rates:
            if not 2000<=rate<=500000:ap.error('Sampling requests must be 2000–500000.')
            # A new connection can contain complete stale packets. Capture the old
            # epoch so an echo of an unchanged rate cannot satisfy the handshake.
            old=None;clock_hz=None
            for f in next_frame(link,parser,time.monotonic()+3):
                old=f.meta['epoch'];clock_hz=f.meta['clock_hz'];break
            if old is None:raise RuntimeError('No firmware frames received.')
            divisor=(clock_hz+rate//2)//rate
            alpha=alpha_for_cutoff(args.cutoff,clock_hz/divisor) if args.cutoff else 0
            link.write(f'S {rate}\nW 1\nF {alpha}\n'.encode())
            first=None
            for f in next_frame(link,parser,time.monotonic()+8):
                m=f.meta;target=(m['clock_hz']+rate//2)//rate
                if m['epoch']!=old and m['divisor']==target and m['window']==1 and m['alpha']==alpha and not m['warm'] and not m['flags']&1 and m['elapsed_ms']>=500:
                    first=f;break
            if first is None:raise RuntimeError(f'Configuration not confirmed for {rate} Hz.')
            epoch=first.meta['epoch'];last=first;bad=False;observed=0
            for f in next_frame(link,parser,time.monotonic()+args.seconds+5):
                if f.meta['epoch']!=epoch:raise RuntimeError('Configuration changed during measurement.')
                last=f;observed+=1
                bad|=bool(f.meta['fault'] or f.meta['clipped'] or f.meta['flags']&1)
                if f.meta['elapsed_ms']-first.meta['elapsed_ms']>=1000*args.seconds:break
            elapsed=(last.meta['elapsed_ms']-first.meta['elapsed_ms'])/1000
            generated=last.meta['valid']-first.meta['valid']
            captured=last.meta['captured']-first.meta['captured']
            skipped=last.meta['skipped']-first.meta['skipped']
            # Report all epoch drops, not only those between the two snapshots.
            clean=(elapsed>=args.seconds and observed>=2 and not bad and
                   last.meta['skipped']==0 and skipped==0 and
                   abs(generated-captured)<=2 and generated>0)
            spectra_s=generated/elapsed if elapsed else 0
            row=dict(requested_fs=rate,lpf_cutoff_hz=args.cutoff,actual_nominal_fs=last.fs,measurement_seconds=elapsed,
                     valid_spectra=generated,captured_blocks=captured,skipped_blocks=skipped,
                     epoch_skipped=last.meta['skipped'],valid_spectra_s=spectra_s,
                     score=last.fs*spectra_s,continuity_check='PASS' if clean else 'FAIL',
                     accuracy_check='REQUIRES_SIGNAL_GENERATOR_AND_SCOPE',
                     fault=last.meta['fault'],max_dsp_us=last.meta['max_dsp_cycles']/last.meta['cpu_hz']*1e6,
                     max_copy_us=last.meta['max_copy_cycles']/last.meta['cpu_hz']*1e6,
                     tx_snapshots_missed=last.meta['tx_dropped'],crc_errors=parser.bad_crc)
            rows.append(row);print(row,flush=True)
    with open(args.output,'w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print('Saved',Path(args.output).resolve())
if __name__=='__main__':main()
