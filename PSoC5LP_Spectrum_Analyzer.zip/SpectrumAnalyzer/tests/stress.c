/* Exercise arithmetic headroom and filter endpoints under ASan/UBSan. */
#include "dsp.h"
#include <stdio.h>
int main(void)
{
    uint16_t raw[128];spectrum_t out;lpf_t s;
    uint32_t seed=12345;
    unsigned test,n;
    const uint32_t alphas[]={0,262144,1000000,500000000,1073741824};
    for(test=0;test<2000;test++) {
        if(test%20==0) lpf_reset(&s,alphas[(test/20)%5]);
        for(n=0;n<128;n++) {
            seed=1664525UL*seed+1013904223UL;
            switch(test%5) {
            case 0:raw[n]=(n&1)?4095:0;break;
            case 1:raw[n]=n==0?4095:0;break;
            case 2:raw[n]=n==0?0:4095;break;
            case 3:raw[n]=4095;break;
            default:raw[n]=(uint16_t)(seed&4095);break;
            }
        }
        spectrum_compute(raw,&s,test%3,&out);
    }
    puts("PASS: 2000 full-scale/edge-case blocks, sanitizer-enabled native C.");
    return 0;
}
