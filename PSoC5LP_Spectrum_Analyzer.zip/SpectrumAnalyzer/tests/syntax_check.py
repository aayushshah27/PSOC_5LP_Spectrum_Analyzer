"""Host-side C syntax only; generated PSoC APIs are stubbed, not verified."""
import subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
    folder=Path(tmp)
    for path in (root/'firmware').glob('*.[ch]'):
        (folder/path.name).write_bytes(path.read_bytes())
    (folder/'project.h').write_bytes((root/'tests/stubs/project.h').read_bytes())
    for usb in [0,1]:
        config=(root/'firmware/config.h').read_text().replace('#define USE_USB_CDC 0',f'#define USE_USB_CDC {usb}')
        (folder/'config.h').write_text(config)
        subprocess.run(['gcc','-std=c99','-Wall','-Wextra','-Werror','-Wno-pointer-to-int-cast','-fsyntax-only',
                        str(folder/'board.c'),str(folder/'main.c'),str(folder/'dsp.c'),str(folder/'wire.c')],check=True)
print('PASS: C syntax, UART and USB branches. Actual Creator build still required.')
