/* Syntax-check stubs ONLY. Never add this file to PSoC Creator. */
#include <stdint.h>
typedef uint8_t uint8;typedef uint16_t uint16;typedef uint32_t uint32;typedef int16_t int16;
#define CY_ISR(name) void name(void)
#define CyGlobalIntEnable ((void)0)
#define HI16(v) ((uint16)((v)>>16))
#define LO16(v) ((uint16)(v))
#define CYRET_SUCCESS 0
#define CY_DMA_INVALID_TD 255
#define TD_INC_DST_ADR 1
#define DMA_ADC__TD_TERMOUT_EN 2
#define ADC_SAR_SAR_WRK_PTR ((volatile uint16*)0x40000000UL)
#define CY_GET_REG16(p) (*(p))
#define USBFS_5V_OPERATION 0
#define UART_TX_STS_FIFO_NOT_FULL 1
void SampClock_Stop(void);void SampClock_Start(void);void SampClock_SetDividerRegister(uint16,uint8);
void CyDelayUs(uint16);void CyDelay(uint32);uint8 CyDmaChDisable(uint8);uint8 CyDmaChEnable(uint8,uint8);
uint8 CyDmaTdSetConfiguration(uint8,uint16,uint8,uint8);uint8 CyDmaTdSetAddress(uint8,uint16,uint16);
void CyDmaClearPendingDrq(uint8);
uint8 CyDmaChSetInitialTd(uint8,uint8);uint8 CyDmaTdAllocate(void);uint8 DMA_ADC_DmaInitialize(uint8,uint8,uint16,uint16);
void isr_dma_Disable(void);void isr_dma_Enable(void);void isr_dma_ClearPending(void);
void isr_dma_StartEx(void(*)(void));void isr_dma_SetPriority(uint8);
uint8 CyEnterCriticalSection(void);void CyExitCriticalSection(uint8);
void ADC_SAR_Start(void);void ADC_SAR_IRQ_Disable(void);int16 ADC_SAR_GetResult16(void);
void UART_Start(void);uint8 UART_ReadTxStatus(void);void UART_PutChar(uint8);
uint8 UART_GetRxBufferSize(void);uint8 UART_GetChar(void);void Probe_FFT_Write(uint8);
void USBFS_Start(uint8,uint8);uint8 USBFS_IsConfigurationChanged(void);uint8 USBFS_GetConfiguration(void);
void USBFS_CDC_Init(void);uint8 USBFS_CDCIsReady(void);void USBFS_PutData(uint8*,uint16);
uint8 USBFS_DataIsReady(void);uint16 USBFS_GetAll(uint8*);
