"""Compile the exact portable MCU DSP/wire C sources and test via ctypes.
Requires GCC, Python and NumPy. No PSoC hardware emulation is claimed.
Run from any directory: python tests/validate.py
"""
import ctypes as C
import csv,json,subprocess,sys,tempfile,zlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'pc'))
from protocol import Parser,KEYS,SIZE,pack
from analysis import peaks,alpha_for_cutoff
N=128
class Filter(C.Structure):
    _fields_=[('alpha',C.c_uint32),('state',C.c_int32),('warm',C.c_uint32),('initialized',C.c_uint8)]
class Spectrum(C.Structure):
    _fields_=[('amplitudes',C.c_uint32*65),('window_sum',C.c_uint32),
              ('minimum',C.c_uint16),('maximum',C.c_uint16),('clipped',C.c_uint16),('warming',C.c_uint8)]

def main():
    checks=[];rows=[]
    def check(condition,label):
        assert condition,label
        checks.append(label)
    with tempfile.TemporaryDirectory() as tmp:
        shared=Path(tmp)/'dsp.so'
        subprocess.run(['gcc','-std=c99','-O2','-Wall','-Wextra','-Werror','-fPIC','-shared',
                        str(ROOT/'firmware/dsp.c'),str(ROOT/'firmware/wire.c'),'-o',str(shared)],check=True)
        lib=C.CDLL(str(shared))
        lib.spectrum_compute.argtypes=[C.POINTER(C.c_uint16),C.POINTER(Filter),C.c_uint,C.POINTER(Spectrum)]
        lib.lpf_reset.argtypes=[C.POINTER(Filter),C.c_uint32]
        lib.integer_sqrt64.argtypes=[C.c_uint64];lib.integer_sqrt64.restype=C.c_uint32
        lib.wire_pack.argtypes=[C.POINTER(C.c_uint8),C.POINTER(C.c_uint32),C.POINTER(C.c_uint32)]
        def run(raw,window=1,filter=None):
            if filter is None:filter=Filter();lib.lpf_reset(C.byref(filter),0)
            raw=np.asarray(raw,dtype=np.uint16)
            out=Spectrum();lib.spectrum_compute((C.c_uint16*128)(*raw),C.byref(filter),window,C.byref(out))
            return np.array(out.amplitudes,dtype=float)/65536,out
        n=np.arange(N);rng=np.random.default_rng(723)
        for _ in range(400):
            fbin=float(rng.uniform(6,58));amp=float(rng.uniform(40,1700));phase=float(rng.uniform(0,2*np.pi))
            raw=np.rint(2048+amp*np.sin(2*np.pi*fbin*n/N+phase)).astype(np.uint16)
            a,out=run(raw);k=int(np.argmax(a));error=100*(a[k]/amp-1)
            f_est=max(peaks(a,32000,1),key=lambda p:p[1])[0]/250
            check(abs(error)<=10,'flat-top off-bin amplitude')
            check(abs(f_est-fbin)<=1,'flat-top frequency within one bin')
            check(not out.clipped,'unclipped test signal')
            rows.append(dict(test='single_tone',bin=fbin,reference_counts=amp,measured_counts=a[k],
                             amplitude_error_percent=error,frequency_error_bins=f_est-fbin))
        for _ in range(150):
            bins=[float(rng.uniform(8,20)),float(rng.uniform(32,53))]
            amps=[float(rng.uniform(180,650)),float(rng.uniform(180,650))]
            phases=rng.uniform(0,2*np.pi,2)
            raw=np.rint(2048+sum(A*np.sin(2*np.pi*b*n/N+p) for A,b,p in zip(amps,bins,phases))).astype(np.uint16)
            a,_=run(raw);p=peaks(a,32000,1)
            for target,amp in zip(bins,amps):
                f,measured,k=min(p,key=lambda v:abs(v[0]/250-target))
                error=100*(measured/amp-1)
                check(abs(error)<=10,'multi-tone amplitude')
                check(abs(f/250-target)<=1,'multi-tone frequency')
                rows.append(dict(test='two_tone',bin=target,reference_counts=amp,measured_counts=measured,
                                 amplitude_error_percent=error,frequency_error_bins=f/250-target))
        windows=[np.ones(N),.21557895-.41663158*np.cos(2*np.pi*n/N)+.277263158*np.cos(4*np.pi*n/N)
                 -.083578947*np.cos(6*np.pi*n/N)+.006947368*np.cos(8*np.pi*n/N),.5-.5*np.cos(2*np.pi*n/N)]
        for wi,w in enumerate(windows):
            for _ in range(50):
                raw=rng.integers(200,3895,128,dtype=np.uint16)
                a,_=run(raw,wi)
                q=np.clip(np.rint(w*32768),-32768,32767)/32768
                ref=2*abs(np.fft.rfft((raw.astype(float)-raw.mean())*q))/q.sum()
                ref[0]=0;ref[-1]/=2
                check(float(np.max(abs(a-ref)))<.65,'all-bin FFT versus NumPy')
        # Known sampled waveforms: reference uses their actual discrete spectrum,
        # not the infinite-bandwidth continuous-wave harmonic approximation.
        for name,x in [('square',np.where(np.sin(2*np.pi*7*n/N+.1)>=0,700,-700)),
                       ('triangle',700*(2/np.pi)*np.arcsin(np.sin(2*np.pi*7*n/N+.1)))]:
            raw=np.rint(2048+x).astype(np.uint16)
            a,_=run(raw,0);ref=2*abs(np.fft.rfft(raw-raw.mean()))/128;ref[0]=0;ref[-1]/=2
            strong=np.flatnonzero(ref>30)
            check(np.max(abs(a[strong]/ref[strong]-1))<.01,name+' harmonic magnitudes')
        for fc in [100,1000,6000]:
            fs=32000;alpha=alpha_for_cutoff(fc,fs);s=Filter();lib.lpf_reset(C.byref(s),alpha)
            total=np.arange(N*100)
            fbin=20;f=fbin*fs/N
            raw=np.rint(2048+700*np.sin(2*np.pi*fbin*total/N)).astype(np.uint16)
            for block in raw.reshape(-1,N):a,o=run(block,0,s)
            aq=alpha/(1<<30);h=aq/abs(1-(1-aq)*np.exp(-2j*np.pi*f/fs))
            check(abs(a[20]/(700*h)-1)<.02,'LPF attenuation at '+str(fc))
            check(not o.warming and s.warm==0,'LPF settles')
            wc=2*np.pi*fc/fs;gain=aq/abs(1-(1-aq)*np.exp(-1j*wc))
            check(abs(gain-1/np.sqrt(2))<1e-5,'LPF cutoff is -3 dB')
        s=Filter();lib.lpf_reset(C.byref(s),alpha_for_cutoff(100,32000))
        _,out=run(np.full(128,2048),1,s)
        check(out.warming==1,'startup settling is flagged')
        _,out=run(np.full(128,4095))
        check(out.clipped==128,'ADC clipping detected')
        a,_=run(np.full(128,2048));check(np.max(a)==0,'DC offset removal')
        for value in [0,1,2,4,9,2**32-1,2**63,2**64-1]:
            root=lib.integer_sqrt64(value)
            check(root*root<=value<(root+1)**2,'integer square root')
        meta=dict.fromkeys(KEYS,0);meta.update(clock_hz=80000000,divisor=2500,cpu_hz=80000000)
        amplitudes=list(range(65));buf=(C.c_uint8*SIZE)()
        lib.wire_pack(buf,(C.c_uint32*24)(*(meta[k] for k in KEYS)),(C.c_uint32*65)(*amplitudes))
        raw_packet=bytes(buf);check(raw_packet==pack(meta,amplitudes),'C/Python wire format and CRC match')
        parser=Parser();received=[]
        corrupted=bytearray(raw_packet);corrupted[70]^=64
        stream=b'noisePS'+bytes(corrupted)+raw_packet+raw_packet
        for start in range(0,len(stream),7):received+=parser.feed(stream[start:start+7])
        check(len(received)==2 and parser.bad_crc==1,'fragmentation, corruption and resynchronization')
        check(received[0].amplitudes==tuple(amplitudes),'packet payload decoded')
    destination=ROOT/'tests'/'results';destination.mkdir(exist_ok=True)
    with (destination/'accuracy.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    summary=dict(status='PASS',assertions=len(checks),tone_measurements=len(rows),
                 max_amplitude_error_percent=max(abs(r['amplitude_error_percent']) for r in rows),
                 max_frequency_error_bins=max(abs(r['frequency_error_bins']) for r in rows),
                 tested_scope='Native host build of exact portable C DSP and wire sources; no board or Creator validation',
                 conditions='Flat-top, isolated tones 6–58 bins, 40–1700 ADC counts peak; two tones separated by >=12 bins')
    (destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
