# Validation performed during package preparation

- Actual `dsp.c` and `wire.c` compiled as a native shared library with GCC,
  C99, `-O2 -Wall -Wextra -Werror`.
- 1,975 numerical/protocol assertions passed. Details and per-tone data are in
  summary.json and accuracy.csv. Single-/two-tone tests use deterministic seed 723.
- The exact C wire serializer matches the Python serializer and CRC, byte for byte.
  Fragmented streams and corruption/resynchronization were exercised.
- 2,000 full-scale/edge-case C processing blocks passed AddressSanitizer and
  UndefinedBehaviorSanitizer. Leak detection was disabled because this runtime's
  process introspection does not support LeakSanitizer; the DSP allocates no heap.
- `board.c` and `main.c` syntax checked in both UART and USB configurations against
  the clearly labeled fake peripheral header. This does **not** verify real APIs.
- Python modules compile; app/benchmark CLI help and imports execute with dependencies.
- PSoC Creator code generation/fitter/linker and flash programming were unavailable.
- Full graphical/serial integration on the user's Windows PC remains untested.
- No board analog accuracy, clock measurement, update rate or score was fabricated.

To reproduce on a host with GCC and NumPy:

```text
python tests/validate.py
python tests/syntax_check.py
gcc -std=c99 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -I firmware tests/stress.c firmware/dsp.c -o spectrum_stress
ASAN_OPTIONS=detect_leaks=0 ./spectrum_stress
```

The sanitizer command is for Linux/macOS shells with the corresponding GCC
runtime. Windows Creator does not need these host tests to build the firmware.
Read docs/CREATOR_SETUP.md for actual target build steps.
